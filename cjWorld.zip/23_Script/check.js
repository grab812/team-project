// document.addEventListener("DOMContentLoaded", function () {
//   const checkDiv = document.querySelector(".CW_portlet_banner");
//   console.log(checkDiv);
//   if (checkDiv) {
//     const parentElement = innerDiv.closest(".ptl_box");
//     const dataHeightValue = parentElement.getAttribute("data-height");
//     console.log("data-height:", dataHeightValue);
//   }
// });
window.onload = () => {
  const iframe = document.getElementById("my-iframe");

  const iframeDocument =
    iframe.contentDocument || iframe.contentWindow.document;
  const checkDiv = iframeDocument.querySelector(".CW_portlet_banner");
  if (checkDiv) {
    const parentElement = checkDiv.closest(".ptl_box");
    console.log("in", checkDiv);
    const dataHeightValue = parentElement.getAttribute("data-height");
    console.log("data-height:", dataHeightValue);
  }
};
