﻿/*
    파일명 : common_func.js
    설명 : Javascript 공통 함수
    작성자 : 이현기
    작성일 : 2012/06/29
*/

/* 일정 아이콘 설정 */
function setCalendar(objCalendarBtn, displayText) {
    //일정 아이콘에 현재일 표시구현
    //월표시 -> 일표시로 변경 [2012/08/21 이현기]
    var currDate

    if (CJWUtil.IsNullOrEmpty(displayText))
        currDate = new Date().getDate();
    else
        currDate = displayText;

    if (CJWUtil.getFileNameFromUrl(location.href).indexOf("_mirror.") > 0) {
        //신규 템플릿경우 현재월 텍스트만 바인딩
        objCalendarBtn.text(currDate);
    }
    else {
        //구 템플릿일 경우 텍스트를 아이콘위에 올린다.
        var parentTd = objCalendarBtn.parents("td").first();
        parentTd.attr("style", "position:relative;");
        parentTd.prepend("<div style='position:absolute; top:11px; left:12px; color:#f8971d; font-size:10px; letter-spacing:-1px; width:21px; text-align:center; cursor:pointer; '>" + currDate + "</div>");
    }
}

function CJWUtil() { };
/* Null 체크 */
CJWUtil.IsNull = function(value) {
    return typeof value == "undefined" || value == null;
}
/* Null이거나 빈문자열 체크 */
CJWUtil.IsNullOrEmpty = function(value) {
    return this.IsNull(value) || value == "";
}
/* URL에서 파일명제외한 경로추출 */
CJWUtil.getPathWithoutFileNameFromUrl = function (url) {
    try {
        return url.substring(0, url.lastIndexOf("/"));
    } catch (ex) {
        return "";
    }
}
/* URL에서 파일명 추출 */
CJWUtil.getFileNameFromUrl = function (url) {
    try {
        return url.substring(url.lastIndexOf("/") + 1, url.length);
    } catch (ex) {
        return "";
    }
}
/* 파라미터 값 추출 */
CJWUtil.getQueryString = function() {
    var key = "";
    if (arguments.length > 0 && arguments[0].length > 1)
        key = arguments[0];
    return this.getQueryValueFromString(location.search.substring(1), key);
}
/* 파라미터 값 추출 */
CJWUtil.getQueryValueFromString = function(queryString, selKey) {
    var key = false, res = {}, itm = null;
    // get the query string without the ?
    var qs = queryString;
    // check for the key as an argument
    if (this.IsNullOrEmpty(selKey) == false)
        key = selKey;
    // make a regex pattern to grab key/value
    var pattern = /([^&=]+)=([^&]*)/g;
    // loop the items in the query string, either
    // find a match to the argument, or build an object
    // with key/value pairs
    while (itm = pattern.exec(qs)) {
        if (key !== false && decodeURIComponent(itm[1]) === key)
            return decodeURIComponent(itm[2]);
        else if (key === false)
            res[decodeURIComponent(itm[1])] = decodeURIComponent(itm[2]);
    }

    return key === false ? res : null;
}

/* 이미지 미리 로딩 */
CJWUtil.preloadImage = function(arrayImgCache) {
	if ($.isArray(arrayImgCache)) {
		if (arguments.length > 1) {
			for (var i = 1; i < arguments.length; i++) {
				var cacheImage = document.createElement("img");
				cacheImage.src = arguments[i];
				arrayImgCache.push(cacheImage);
			}
		}
	}
}

var console = window.console || { log: function() { } };    //IE8이하에서 오류방지를 위한 코드
//컨텐츠 팝업 띄우기 클래스
function ContentsPopup() {
    //Public
    this.ContentsID = (arguments.length > 0 ? arguments[0] : "");   //컨텐츠 ID
    this.ParamWorkspaceID = (arguments.length > 1 ? arguments[1] : ""); //파라미터 WorkspaceID
    this.IsUseCustomSet = true; //설정 팝업정보 사용여부
    this.ParamPattern = 1;   //파라미터 Pattern
    this.ParamControlMode = "FULL"; //파라미터 ControlMode
    this.WindowNamePrefix = "open"; //팝업윈도우 접두어
    this.IsAutoFocus = true;   //창오픈후 자동 포커스여부
    //Private
    var popupLeft = 0;          //새창 가로 위치
    var popupTop = 0;           //새창 세로 위치
    var popupWidth = (arguments.length > 3 ? arguments[3] : 850);       //새창 가로 크기
    var popupHeight = (arguments.length > 4 ? arguments[4] : 600);      //새창 세로 크기
    var optionMenuBar = 0;      //새창 메뉴바 속성
    var optionToolBar = 0;      //새창 툴바 속성
    var optionLocation = 0;     //새창 로케이션 속성
    var optionDirectories = 0;  //새창 디렉토리 속성
    var optionStatus = 0;       //새창 상태표시줄 속성
    var optionScrollBars = 1;   //새창 스크롤바 속성
    var optionResizable = 1;    //새창 리사이즈 속성
    //창오픈
    this.openContents = function() {
        //커스텀 설정을 사용한다면 설정값 가져오기
        if (this.IsUseCustomSet == true)
            getCustomSet(this.ContentsID);

        var screenWidth = window.screen.width;  //화면가로크기
        var screenHeight = window.screen.height;    //화면세로크기

        popupWidth = (popupWidth > screenWidth ? screenWidth : popupWidth);    //화면의 크기에 맞게 새창크기 조정
        popupHeight = (popupHeight > screenHeight ? screenHeight : popupHeight);    //화면의 크기에 맞게 새창크기 조정

        if (popupLeft == 0 || screenWidth == popupWidth) //좌측위치 값이 0이면 화면 중간으로(새창크기가 화면크기보다 클 경우 위치 설정 무시)
            popupLeft = (screenWidth - popupWidth) / 2;
        if (popupTop == 0 || screenHeight == popupHeight)  //상단위치 값이 0이거나 화면 중간으로(새창크기가 화면크기보다 클 경우 위치 설정 무시)
            popupTop = (screenHeight - popupHeight) / 2;

        //새창 속성 설정
        var popupOptionString = "width=" + popupWidth
        popupOptionString += ", height=" + popupHeight
        popupOptionString += ", left=" + popupLeft
        popupOptionString += ", top=" + popupTop;
        popupOptionString += ", menubar=" + optionMenuBar;
        popupOptionString += ", toolbar=" + optionToolBar;
        popupOptionString += ", location=" + optionLocation;
        popupOptionString += ", directories=" + optionDirectories;
        popupOptionString += ", status=" + optionStatus;
        popupOptionString += ", scrollbars=" + optionScrollBars;
        popupOptionString += ", resizable=" + optionResizable;
        
        var contentsWindow = window.open("/PT/PortalBuilder/Framework/contents.aspx?WORKSPACE_ID=" + this.ParamWorkspaceID + "&PATTERN=" + this.ParamPattern + "&CONTROL_MODE=" + this.ParamControlMode + "&CONTENTS_ID=" + this.ContentsID, this.WindowNamePrefix + this.ContentsID, popupOptionString);
        if (this.IsAutoFocus == true)
            contentsWindow.focus();
    }
    //팝업 설정값 가져오기
    var getCustomSet = function(ctID) {
        try {
            $.ajax({ url: "/PT/Common/Webservice/WSContentsDetail.aspx",
                data: { ContentsID: ctID },
                type: "POST",
                async: false,
                error: function(xhr) {
                    console.log("Ajax error:" + xhr.responseText);
                },
                success: function(data) {
                    if (data.ResultCode == 0) {
                        //팝업타입이 타이틀팝업일 경우에 설정값 가져오기
                        if (data.PopupType == 3) {
                            popupLeft = data.PopupLeft;
                            popupTop = data.PopupTop;
                            popupWidth = data.PopupWidth;
                            popupHeight = data.PopupHeight;

                            var optionString = data.PopupOption;  //팝업창 옵션 설정 문자열
                            if (CJWUtil.IsNullOrEmpty(optionString) == false) {
                                //팝업창 옵션 설정 문자열이 있다면 설정 가져옴
                                for (var i = 0; i < optionString.length; i++) {
                                    var optionValue = Number(optionString.charAt(i) == "Y");    //설정을 논리형으로 변경
                                    switch (i) {
                                        case 0:
                                            optionMenuBar = optionValue;
                                            break;
                                        case 1:
                                            optionToolBar = optionValue;
                                            break;
                                        case 2:
                                            optionLocation = optionValue;
                                            break;
                                        case 3:
                                            optionDirectories = optionValue;
                                            break;
                                        case 4:
                                            optionStatus = optionValue;
                                            break;
                                        case 5:
                                            optionScrollBars = optionValue;
                                            break;
                                        case 6:
                                            optionResizable = optionValue;
                                            break;
                                        default:
                                            break;
                                    }
                                }
                            }
                        }
                    }
                    else {
                        console.log("Data error:" + data.ErrorMsg);
                    }
                }
            });
        } catch (ex) {
            console.log("Function error:" + ex.message);
        }
    }
}

    function LoginM365() {
        // Login 시 db설정하기
        //_set_cookie_param('N_CJW','us365', 'Y');
        //$.post('/PT/PortalBuilder/main.aspx?mode=bmode&m365_mode=Y');

        var url = "https://cj.cj.net/portalupload/httpdocs/M365/23_M365_Login_New.html?ctt=mainFrame2&hn=" + window.location.hostname;
        var hleft = 580;	//--Pop-up창의 가로크기
        var htop = 700;		//--Pop-up창의 세로크기

        var vleft = (window.screen.width - hleft) / 2;  //--Pop-up창의 가로시작 좌표점
        var vtop = (window.screen.height - htop) / 2;   //--Pop-up창의 세로시작 좌표점

        var win = window.open(url, "m365Login", "toolbar=no,directories=no,status=no,scrollbars=yes,menubar=no,resizable=yes,width=" + hleft + ",height=" + htop + ",left=" + vleft + ",top=" + vtop);
        win.focus();
    }

  function InsClickLog(from,contents_id,detail)
    {
        var params = { "mode": "clicklog","CFROM":from,"CRESOURCE_ID":contents_id,"CDETAIL":detail}; 
        $.ajax({
                type: "POST",
                url: "/PT/PortalBuilder/23_click_log_ins.aspx",
                data:$.param(params),
                dataType: "json",
                success: function (data) {
                },
                error: function (e) {
                }
            });
    }