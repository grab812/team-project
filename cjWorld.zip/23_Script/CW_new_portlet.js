//20230530 추가 
//세로 슬라이드 - slider_class: 슬라이드 클래스명, col_num: 가로 슬라이드 개수, row_num: 세로 슬라이드 개수,  scroll_num: 한번에 넘기는 스크롤 개수
function slider_vertical(slider_class, col_num, row_num, scroll_num){ 
    row_num = (typeof row_num !== 'undefined') ?  row_num : 1 
    var options = {};
    
    if ($(slider_class + ' .slide').hasClass('no_data')) {
        options = {
            vertical: true,
            infinite: false,
            dots: false,
            arrows: false,
            slidesPerRow: 1,
            rows: 1,
            autoplay: false,
        }
        $(slider_class+' + .slider_bottom').hide(); 
        
    } else if ($(slider_class + ' .slide').length < (col_num * row_num + 1)) { 
        options = {
            vertical: true,
            infinite: false,
            dots: false,
            arrows: false,
            slidesPerRow: col_num, 
            rows: row_num,
            autoplay: false,
        }
        $(slider_class+' + .slider_bottom').hide(); 
        
    } else {
        options = {
            vertical: true,
            infinite: true,
            dots: false,
            arrows: true,
            prevArrow: $('.slick-prev'),
            nextArrow: $('.slick-next'),
            slidesToScroll:scroll_num,
            slidesToShow:row_num,
            slidesPerRow: col_num, 
            //rows: row_num, 
            autoplay: true,
            autoplaySpeed: 2000,
            pauseOnHover: true,
        }
        $(slider_class+' + .slider_bottom').show(); 
    }

     $(slider_class).not('.slick-initialized').slick(options);
    
    //자동재생 정지, 시작 버튼
    $(slider_class+' + .slider_bottom .btn-stop, '+slider_class+' + .slider_bottom .btn-play').click(function(){
        $(this).hide();
        switch( $(this).attr("class")){
            case "btn-stop": $(slider_class).slick('slickPause'); $('.btn-play').show(); break;
            case "btn-play": $(slider_class).slick('slickPlay'); $('.btn-stop').show(); break;
        }
    });
}

//20230303 삭제 - 포틀릿 내용 펼치기
function ptlList_toggled(listId,ptlId){
    var list_li = $('#'+listId).find('li');   
    var parent_box = $('#'+ptlId, window.parent.document);
    var ptl_body = $('#'+listId).parents('.CW_portlet_body');
    var ptl_top =  ptl_body.prev('.CW_portlet_top');
    var list_H = 0;
    //상단 CW_portlet_top가 있는지 여부
    if(ptl_top.length){
        list_H = (list_li.length * 27) + ptl_top.innerHeight() + 88;
    }else{
        list_H = (list_li.length * 27) + 76;
    }
    
    //기존 높이보다 크면 펼치기
    if(list_H > 300){   
        parent_box.toggleClass('is_unfolded');   
        ptl_body.toggleClass('is_unfolded');
        if(parent_box.hasClass('is_unfolded')){
            parent_box.css('height', list_H+'px');    
        }else{
            parent_box.css('height', '');    
        } 
    }
}

//일정 포틀릿 내용 펼치기
function ptlPlannerList_toggled(listId,ptlId){ 
    var parent_box = $('#'+ptlId, window.parent.document);
    var ptl_body = $('#'+listId).parents('.CW_portlet_body')
    var list_H = 0;
    var $li = $('#'+listId).find('li');
    $li.each(function(){
        this_H = $(this).innerHeight();
        list_H = list_H + this_H ;    
    });
    parent_box.toggleClass('is_unfolded');   
    ptl_body.toggleClass('is_unfolded');
    if(parent_box.hasClass('is_unfolded')){
        parent_box.css('height', list_H+149+'px');    
    }else{
        parent_box.css('height', '');    
    }
}

//배너 슬라이드 : slider_class: 슬라이드 클래스명, col_num: 가로 슬라이드 개수   
function slider_int(slider_class, col_num){
    var options = {};

    if ( $(slider_class+' .swiper-slide').hasClass('no_data')) {
        options = {
            slidesPerView: 1,
            loop: false,
            observer: true,
            observeParents: true,
            spaceBetween: 0,
            autoplay: false,
            pauseControls:true,
            pagination: {
              el: ".swiper-pagination",
              clickable: true,
            },
        }
        $(slider_class+' .slider_bottom').hide(); //20230511 추가
    }else if( $(slider_class+' .swiper-slide').length < (col_num + 1) ){
        options = {
            slidesPerView: col_num,
            loop: false,
            observer: true,
            observeParents: true,
            spaceBetween: 6, //20230315 슬라이드간 여백 10 -> 6으로 수정
            autoplay: false,
            pauseControls:true,
            pagination: {
              el: ".swiper-pagination",
              clickable: true,
            },
        }
        $(slider_class+' .slider_bottom').hide(); //20230511 추가
             
     } else {
        options = {
            slidesPerView: col_num,
            //slidesPerGroup: 3,
            loop: true,
            observer: true,
            observeParents: true,
            spaceBetween: 6, //20230315 슬라이드간 여백 10 -> 6으로 수정
            autoplay: {
                delay: 2000,
                disableOnInteraction: false,
            },
            pauseControls:true,
            pagination: {
              el: ".swiper-pagination",
              clickable: true,
            },
        }
         $(slider_class+' .slider_bottom').show(); //20230511 추가
    }
    var swiper = new Swiper(slider_class, options);
    
    //마우스오버시 일시정지
    $(slider_class + ' .swiper-slide').hover(function () {
        swiper.autoplay.stop();
    }, function () {
        if ($(slider_class + ' .btn-play').css('display') == 'none') {
            swiper.autoplay.start();
        }
    });
        
   
    //자동재생 정지, 시작 버튼
    $(slider_class+' .btn-stop, '+slider_class+' .btn-play').click(function(){
        $(this).hide();
        switch( $(this).attr("class")){
            case "btn-stop": swiper.autoplay.stop(); $('.btn-play').show(); break;
            case "btn-play": swiper.autoplay.start(); $('.btn-stop').show(); break;
        }
    });
}


//CoP 배너 슬라이드 - slider_class: 슬라이드 클래스명, col_num: 가로 슬라이드 개수      
function slider_nav_int(slider_class, col_num){
    var options = {};

    if ( $(slider_class+' .swiper-slide').hasClass('no_data')) {
        options = {
            slidesPerView: 1,
            loop: false,
            autoplay: false,
            observer: true,
            observeParents: true,
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
        }
    }else if( $(slider_class+' .swiper-slide').length < (col_num + 1)){
        options = {
            slidesPerView: col_num,
            loop: false,
            autoplay: false,
            observer: true,
            observeParents: true,
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
        }
             
     } else {
        options = {
            slidesPerView: col_num,
            //slidesPerGroup: col_num,
            loop: false,
            autoplay: false,
            observer: true,
            observeParents: true,
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
        }
    }
    var swiper = new Swiper(slider_class, options);
}


//auto 슬라이드 - 채널CJ 
function slider_perAuto_int(slider_class){
    var options = {};

    if ( $(slider_class+' .swiper-slide').hasClass('no_data')) {
        options = {
            slidesPerView: 1,
            loop: false,
            observer: true,
            observeParents: true,
            spaceBetween: 0,
            autoplay: false,
            pauseControls:true,
            pagination: {
              el: ".swiper-pagination",
              clickable: true,
            },
        }
        $(slider_class+' .slider_bottom').hide(); //20230511 추가
        
    }else if( $(slider_class+' .swiper-slide').length < 2){
        options = {
            slidesPerView: "auto",
            loop: false,
            observer: true,
            observeParents: true,
            spaceBetween: 24,
            autoplay: false,
            pauseControls:true,
            pagination: {
              el: ".swiper-pagination",
              clickable: true,
            },
        }
        $(slider_class+' .slider_bottom').hide(); //20230511 추가
             
     } else {
        options = {
            slidesPerView: "auto",
            //slidesPerGroup: 3,
            loop: true,
            observer: true,
            observeParents: true,
            spaceBetween: 24,
            autoplay: {
                delay: 2000,
                disableOnInteraction: false,
            },
            pauseControls:true,
            pagination: {
              el: ".swiper-pagination",
              clickable: true,
            },
        }
         $(slider_class+' .slider_bottom').show(); //20230511 추가
    }
    var swiper = new Swiper(slider_class, options);
    
    //마우스오버시 일시정지
    $(slider_class + ' .swiper-slide').hover(function () {
        swiper.autoplay.stop();
    }, function () {
        if ($(slider_class + ' .btn-play').css('display') == 'none') {
            swiper.autoplay.start();
        }
    });
   
    //자동재생 정지, 시작 버튼
    $(slider_class+' .btn-stop, '+slider_class+' .btn-play').click(function(){
        $(this).hide();
        switch( $(this).attr("class")){
            case "btn-stop": swiper.autoplay.stop(); $('.btn-play').show(); break;
            case "btn-play": swiper.autoplay.start(); $('.btn-stop').show(); break;
        }
    });
}

//세로2단이상 슬라이드 - slider_class: 슬라이드 클래스명, col_num: 가로 슬라이드 개수, row_num: 세로 슬라이드 개수 :20230412 수정       
function slider_gird_int(slider_class, col_num, row_num){ //20230412 row_num 추가
    row_num = (typeof row_num !== 'undefined') ?  row_num : 2 //20230412 추가
    var options = {};
    
    if ($(slider_class + ' .slide').hasClass('no_data')) {
        options = {
            infinite: false,
            dots: false,
            arrows: false,
            //slidesToShow: 1, //20230315 삭제
            //slidesToScroll: 1, //20230315 삭제 
            slidesPerRow: 1, //20230315 추가
            rows: 1,
            autoplay: false,
        }
        $(slider_class+' + .slider_bottom').hide(); //20230511 추가
        
    } else if ($(slider_class + ' .slide').length < (col_num * row_num + 1)) { //20230412 수정
        options = {
            infinite: false,
            dots: true,
            appendDots: $('.slider-dots'),
            arrows: false,
            //slidesToShow: col_num, //20230315 삭제
            //slidesToScroll: col_num, //20230315 삭제
            slidesPerRow: col_num, //20230315 추가
            rows: row_num,//20230412 수정
            autoplay: false,
        }
        $(slider_class+' + .slider_bottom').hide(); //20230511 추가
        
    } else {
        options = {
            infinite: true,
            dots: true,
            appendDots: $('.slider-dots'),
            arrows: false,
            //slidesToShow: col_num, //20230315 삭제
            //slidesToScroll: col_num, //20230315 삭제
            slidesPerRow: col_num, //20230315 추가
            rows: row_num, //20230412 수정
            autoplay: true,
            autoplaySpeed: 2000,
            pauseOnHover: true,
        }
        $(slider_class+' + .slider_bottom').show(); //20230511 추가
    }

     $(slider_class).not('.slick-initialized').slick(options);
    
    //자동재생 정지, 시작 버튼
    $(slider_class+' + .slider_bottom .btn-stop, '+slider_class+' + .slider_bottom .btn-play').click(function(){
        $(this).hide();
        switch( $(this).attr("class")){
            case "btn-stop": $(slider_class).slick('slickPause'); $('.btn-play').show(); break;
            case "btn-play": $(slider_class).slick('slickPlay'); $('.btn-stop').show(); break;
        }
    });
}


//20230117 수정-->
//첫번째 글자 가져오기
function thumb_txt_int(class_name){
    $(class_name).each(function () {
        var txt = $(this).find('.thumb span'),
            tit = $(this).find('.tit').text().replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/ ]/gim, ''), //특수문자, 괄호, 점, 공백 제거
            tit2 = removeEmojis(tit); //이모지 제거
            str = tit2.charAt(0);
        txt.text(str);
    });    
}

//이모지 제거
function removeEmojis(str) {
  var regex = /(?:[\u261D\u26F9\u270A-\u270D]|\uD83C[\uDF85\uDFC2-\uDFC4\uDFC7\uDFCA-\uDFCC]|\uD83D[\uDC42\uDC43\uDC46-\uDC50\uDC66-\uDC69\uDC6E\uDC70-\uDC78\uDC7C\uDC81-\uDC83\uDC85-\uDC87\uDCAA\uDD74\uDD75\uDD7A\uDD90\uDD95\uDD96\uDE45-\uDE47\uDE4B-\uDE4F\uDEA3\uDEB4-\uDEB6\uDEC0\uDECC]|\uD83E[\uDD18-\uDD1C\uDD1E\uDD1F\uDD26\uDD30-\uDD39\uDD3D\uDD3E\uDDD1-\uDDDD])(?:\uD83C[\uDFFB-\uDFFF])?|(?:[\u231A\u231B\u23E9-\u23EC\u23F0\u23F3\u25FD\u25FE\u2614\u2615\u2648-\u2653\u267F\u2693\u26A1\u26AA\u26AB\u26BD\u26BE\u26C4\u26C5\u26CE\u26D4\u26EA\u26F2\u26F3\u26F5\u26FA\u26FD\u2705\u270A\u270B\u2728\u274C\u274E\u2753-\u2755\u2757\u2795-\u2797\u27B0\u27BF\u2B1B\u2B1C\u2B50\u2B55]|\uD83C[\uDC04\uDCCF\uDD8E\uDD91-\uDD9A\uDDE6-\uDDFF\uDE01\uDE1A\uDE2F\uDE32-\uDE36\uDE38-\uDE3A\uDE50\uDE51\uDF00-\uDF20\uDF2D-\uDF35\uDF37-\uDF7C\uDF7E-\uDF93\uDFA0-\uDFCA\uDFCF-\uDFD3\uDFE0-\uDFF0\uDFF4\uDFF8-\uDFFF]|\uD83D[\uDC00-\uDC3E\uDC40\uDC42-\uDCFC\uDCFF-\uDD3D\uDD4B-\uDD4E\uDD50-\uDD67\uDD7A\uDD95\uDD96\uDDA4\uDDFB-\uDE4F\uDE80-\uDEC5\uDECC\uDED0-\uDED2\uDEEB\uDEEC\uDEF4-\uDEF8]|\uD83E[\uDD10-\uDD3A\uDD3C-\uDD3E\uDD40-\uDD45\uDD47-\uDD4C\uDD50-\uDD6B\uDD80-\uDD97\uDDC0\uDDD0-\uDDE6])|(?:[#\*0-9\xA9\xAE\u203C\u2049\u2122\u2139\u2194-\u2199\u21A9\u21AA\u231A\u231B\u2328\u23CF\u23E9-\u23F3\u23F8-\u23FA\u24C2\u25AA\u25AB\u25B6\u25C0\u25FB-\u25FE\u2600-\u2604\u260E\u2611\u2614\u2615\u2618\u261D\u2620\u2622\u2623\u2626\u262A\u262E\u262F\u2638-\u263A\u2640\u2642\u2648-\u2653\u2660\u2663\u2665\u2666\u2668\u267B\u267F\u2692-\u2697\u2699\u269B\u269C\u26A0\u26A1\u26AA\u26AB\u26B0\u26B1\u26BD\u26BE\u26C4\u26C5\u26C8\u26CE\u26CF\u26D1\u26D3\u26D4\u26E9\u26EA\u26F0-\u26F5\u26F7-\u26FA\u26FD\u2702\u2705\u2708-\u270D\u270F\u2712\u2714\u2716\u271D\u2721\u2728\u2733\u2734\u2744\u2747\u274C\u274E\u2753-\u2755\u2757\u2763\u2764\u2795-\u2797\u27A1\u27B0\u27BF\u2934\u2935\u2B05-\u2B07\u2B1B\u2B1C\u2B50\u2B55\u3030\u303D\u3297\u3299]|\uD83C[\uDC04\uDCCF\uDD70\uDD71\uDD7E\uDD7F\uDD8E\uDD91-\uDD9A\uDDE6-\uDDFF\uDE01\uDE02\uDE1A\uDE2F\uDE32-\uDE3A\uDE50\uDE51\uDF00-\uDF21\uDF24-\uDF93\uDF96\uDF97\uDF99-\uDF9B\uDF9E-\uDFF0\uDFF3-\uDFF5\uDFF7-\uDFFF]|\uD83D[\uDC00-\uDCFD\uDCFF-\uDD3D\uDD49-\uDD4E\uDD50-\uDD67\uDD6F\uDD70\uDD73-\uDD7A\uDD87\uDD8A-\uDD8D\uDD90\uDD95\uDD96\uDDA4\uDDA5\uDDA8\uDDB1\uDDB2\uDDBC\uDDC2-\uDDC4\uDDD1-\uDDD3\uDDDC-\uDDDE\uDDE1\uDDE3\uDDE8\uDDEF\uDDF3\uDDFA-\uDE4F\uDE80-\uDEC5\uDECB-\uDED2\uDEE0-\uDEE5\uDEE9\uDEEB\uDEEC\uDEF0\uDEF3-\uDEF8]|\uD83E[\uDD10-\uDD3A\uDD3C-\uDD3E\uDD40-\uDD45\uDD47-\uDD4C\uDD50-\uDD6B\uDD80-\uDD97\uDDC0\uDDD0-\uDDE6])\uFE0F/g;
  return str.replace(regex, '');
}
//-->20230117 수정
