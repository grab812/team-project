﻿
// 2023-03-02 kids2net
// cross-origin 처리 모듈
// - 도메인이 다른 윈도우(frame 및 iframe) 간 메세지 전달/수신 모듈
//
// document.domain 이 더 이상 지원되지 않음
// main 창과 도메인이 다른 자식창에 이 스크립트 링크해야 됨
//
// ref - https://developer.mozilla.org/en-US/docs/Web/API/Window/postMessage


// 수신
window.addEventListener("message", (event) => {
    //if (event.origin !== "http://example.org:8080") return;
    var msg = event.data;
    //console.log(msg, window);

    if(typeof msg == 'string') {
        if(msg in window) window[msg]();
    }
    else {
        if(msg.func in window) window[msg.func](msg);
    }
}, false);



//크로스모드 css설정
function CrossSetCss(msg){

    if(!msg.recur) {
        if(msg.set)
            $('body').addClass(msg.css);
        else
            $('body').removeClass(msg.css);

        // 20230321 전체 새로고침 시 dark_mode/wide_mode 유지를 위해 쿠키 필요
        if(top == self){
            if(msg.css == 'dark_mode'){
                _set_cookie_param('N_CJW','bmD', msg.set ? 'Y' : 'N');
                $.post('?mode=bmode&dark_mode='+(msg.set ? 'Y' : 'N'));
            }
            else if(msg.css == 'wide_mode'){
                _set_cookie_param('N_CJW','bmW', msg.set ? 'Y' : 'N');
                $.post('?mode=bmode&wide_mode='+(msg.set ? 'Y' : 'N'));
            }
        }
    }

    (msg.target || $('iframe')).each(function(){
        try {

            if(msg.set)
                $(this).contents().find('body').addClass(msg.css);
            else
                $(this).contents().find('body').removeClass(msg.css);

            CrossSetCss({ // 재귀 호출
                css: msg.css,
                set: msg.set,
                recur: 1,
                target: $(this).contents().find('iframe')
            });

        } catch(e) { // cross-origin..

            $(this).get(0).contentWindow.postMessage({
                func: 'CrossSetCss',
                css: msg.css,
                set: msg.set
            }, '*');

        }
    });
}

// 20230321 전체 새로고침 시 dark_mode/wide_mode 유지를 위해 쿠키 필요
function _set_cookie(name, value, expiredays) {
    var todayDate = new Date();
    todayDate.setDate(todayDate.getDate() + expiredays);
    document.cookie = name + "=" + escape(value) + "; domain=.cj.net; path=/; expires=" + todayDate.toGMTString() + ";"
}
// 20230327
function _get_cookie(name) {
    var cname = name + "=";
    var dc = document.cookie;
    if (dc.length > 0) {
        begin = dc.indexOf(cname);
        if (begin != -1) {
            begin += cname.length;
            end = dc.indexOf(";", begin);
            if (end == -1) end = dc.length;
            return unescape(dc.substring(begin, end));
        }
    }
    return null;
}


// 20230427 N_CJW/_ncjw k=v&k=v param 형태 쿠키 관리
function _set_cookie_param(master, key, value) {
    var dom = '.cj.net';
    if(master == '_ncjw') dom = 'cj.cj.net';
    var cookies = _get_cookie(master) || '';
    var cookies2 = _add_cookie_param(cookies, key, escape(value));
    document.cookie = master + "=" + cookies2 + "; domain=" + dom + "; path=/;"
}

function _add_cookie_param(cookies, key, value)
{
    if(cookies == '') return key+'='+value;

    var exist = false;
    var kvs = cookies.split('&');
    for(var i=0; i<kvs.length; i++)
    {
        var kv = kvs[i].split('=');
        if(kv[0] == key) {
            kvs[i] = key + '=' + value;
            exist = true;
            break;
        }
    }
    if(!exist) kvs.push(key+'='+value);

    return kvs.join('&');
}

function _get_cookie_param(master, key) {
    var cookies = _get_cookie(master) || '';
    if(cookies == '') return '';

    var kvs = cookies.split('&');
    for(var i=0; i<kvs.length; i++)
    {
        var kv = kvs[i].split('=');
        if(kv[0] == key) return kv[1];
    }
    return '';
}
// 20230427 N_CJW/_ncjw k=v&k=v param 형태 쿠키



if(!('postMessage' in window)) {
    document.domain = 'cj.net'; // 구 브라우저 호환
}


//20230407 top click trigger
function click_trigger() {
    $(document).trigger('click');
}

//20230407 - 하위 iframe들에서 호출 top.postMessage('click_trigger','*');
$(document).on('click',function(){
    if(parent != self && !$(event.target).closest('.popup_mode').length)  //20230601 수정(알림창 팝업안닫히게)
        parent.postMessage('click_trigger','*');
});


//20230418 통합검색 2차/3차 활성탭 유지 - 20230426 쿠키에서 top변수로 변경
//20230426 히스토리 탭 유지 추가 #####################
function check_blank(){
    if($('#ifm_sub_search').get(0).contentWindow.location == 'about:blank')
        parent.postMessage('get_current_tab2', '*'); // 비동기 post
}
function get_current_tab2(msg){ // 비동기 post
    $('#ifm_main_search').get(0).contentWindow.postMessage({
        func: 'recv_current_tab2',
        TS_TAB2: parent.TS_TAB2
    }, '*');
}
function recv_current_tab2(msg){ // 비동기 recv
    var _curbtn = $('button[data-id='+msg.TS_TAB2+']');
    if(_curbtn.length == 0)
        var _curbtn = $('.sub_tabList button:first');
    (new Function(_curbtn.attr('onclick')))();
    _curbtn.addClass('active');
}

function _set_current_tab2(tab2){
    parent.parent.postMessage({
        func: 'set_current_tab',
        TS_TAB2: tab2
    }, '*');
}
function set_current_tab1(msg){ // 1차프레임 전용 - 히스토리 이동시 하위frame에서 호출
    parent.TS_TAB1 = msg.TS_TAB1;
    $('button.active').removeClass('active');
    $('button[data-id='+msg.TS_TAB1+']').addClass('active');
}
function set_current_tab2(msg){ // 2차프레임들 전용 - 히스토리 이동시 하위frame에서 호출
    _set_current_tab2(msg.TS_TAB2);
    $('button.active').removeClass('active');
    $('button[data-id='+msg.TS_TAB2+']').addClass('active');
}
function check_search_tab1(){
    if(location.href.indexOf('ts_tab1=') == -1) return;
    var tab1 = location.href.split('ts_tab1=').pop().split('&').shift();
    parent.postMessage({func:'set_current_tab1',TS_TAB1:tab1},'*');
}
function check_search_tab2(){
    if(location.href.indexOf('ts_tab2=') == -1) return;
    var tab2 = location.href.split('ts_tab2=').pop().split('&').shift();
    parent.postMessage({func:'set_current_tab2',TS_TAB2:tab2},'*');
}

$(document).ready(function(){
    check_search_tab1();
    check_search_tab2();
});
//20230418 통합검색 2차/3차 활성탭 유지 - 20230426 쿠키에서 top변수로 변경
